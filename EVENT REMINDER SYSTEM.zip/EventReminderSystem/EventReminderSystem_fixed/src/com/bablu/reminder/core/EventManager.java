package com.bablu.reminder.core;

import com.bablu.reminder.storage.Storage;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EventManager {
    private final Storage storage;
    private final List<Event> events = new ArrayList<>();

    public EventManager(Storage storage) {
        this.storage = storage;
        events.addAll(storage.load());
        sort();
    }

    public List<Event> all() {
        return new ArrayList<>(events);
    }

    public void add(Event e) {
        events.add(e);
        sort();
        storage.save(events);
    }

    public void update(Event updated) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).getId().equals(updated.getId())) {
                events.set(i, updated);
                sort();
                storage.save(events);
                return;
            }
        }
    }

    public void removeById(String id) {
        events.removeIf(e -> e.getId().equals(id));
        storage.save(events);
    }

    public Optional<Event> findById(String id) {
        return events.stream().filter(e -> e.getId().equals(id)).findFirst();
    }

    public List<Event> upcomingOnly() {
        LocalDateTime now = LocalDateTime.now();
        return events.stream()
                .filter(e -> !e.isDone() && (e.getDateTime().isAfter(now) || e.getDateTime().isEqual(now)))
                .sorted(Comparator.comparing(Event::getDateTime))
                .collect(Collectors.toList());
    }

    private void sort() {
        events.sort(Comparator.comparing(Event::getDateTime));
    }
}
package com.bablu.reminder.core;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.UUID;

public class Event {
    public enum Repeat {
        NONE, DAILY, WEEKLY
    }

    private final String id;
    private String title;
    private String description;
    private LocalDateTime dateTime;
    private Repeat repeat;
    private boolean done;

    public Event(String title, String description, LocalDateTime dateTime, Repeat repeat) {
        this(UUID.randomUUID().toString(), title, description, dateTime, repeat, false);
    }

    public Event(String id, String title, String description, LocalDateTime dateTime, Repeat repeat, boolean done) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dateTime = dateTime;
        this.repeat = repeat;
        this.done = done;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDateTime getDateTime() { return dateTime; }
    public Repeat getRepeat() { return repeat; }
    public boolean isDone() { return done; }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setDateTime(LocalDateTime dateTime) { this.dateTime = dateTime; }
    public void setRepeat(Repeat repeat) { this.repeat = repeat; }
    public void setDone(boolean done) { this.done = done; }

    public String toDisplayString() {
        return String.format("%s @ %s (%s)%s",
                title,
                dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                repeat,
                done ? " [DONE]" : "");
    }

    @Override
    public String toString() {
        return "Event{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", dateTime=" + dateTime +
                ", repeat=" + repeat +
                ", done=" + done +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Event event = (Event) o;
        return Objects.equals(id, event.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
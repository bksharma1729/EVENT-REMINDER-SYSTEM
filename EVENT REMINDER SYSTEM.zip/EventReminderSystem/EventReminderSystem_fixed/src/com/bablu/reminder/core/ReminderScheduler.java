package com.bablu.reminder.core;

import javafx.application.Platform;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public class ReminderScheduler {
    private final EventManager manager;
    private final ScheduledExecutorService pool = Executors.newSingleThreadScheduledExecutor();
    private Consumer<Event> onDue;

    public ReminderScheduler(EventManager manager, Consumer<Event> onDue) {
        this.manager = manager;
        this.onDue = onDue;
    }

    public void start() {
        pool.scheduleAtFixedRate(this::check, 0, 30, TimeUnit.SECONDS);
    }

    public void stop() {
        pool.shutdownNow();
    }

    private void check() {
        List<Event> list = manager.all();
        LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS);
        for (Event e : list) {
            if (e.isDone()) continue;
            LocalDateTime dt = e.getDateTime().truncatedTo(ChronoUnit.SECONDS);
            if (!now.isBefore(dt)) {
                Platform.runLater(() -> onDue.accept(e));
                if (e.getRepeat() == Event.Repeat.DAILY) {
                    e.setDateTime(e.getDateTime().plusDays(1));
                } else if (e.getRepeat() == Event.Repeat.WEEKLY) {
                    e.setDateTime(e.getDateTime().plusWeeks(1));
                } else {
                    e.setDone(true);
                }
                manager.update(e);
            }
        }
    }
}
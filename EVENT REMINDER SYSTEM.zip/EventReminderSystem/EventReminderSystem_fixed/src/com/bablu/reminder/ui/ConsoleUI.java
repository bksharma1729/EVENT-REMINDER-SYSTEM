package com.bablu.reminder.ui;

import com.bablu.reminder.core.Event;
import com.bablu.reminder.core.EventManager;
import com.bablu.reminder.core.ReminderScheduler;
import com.bablu.reminder.storage.Storage;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {

    public static void start() {
        Storage storage = new Storage();
        EventManager manager = new EventManager(storage);
        ReminderScheduler scheduler = new ReminderScheduler(manager, e -> {
            System.out.println("\n[REMINDER] " + e.toDisplayString());
            System.out.print("> ");
        });
        scheduler.start();

        Scanner sc = new Scanner(System.in);
        System.out.println("Event Reminder System (Console). Type 'help' for commands.");
        System.out.print("> ");
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.equalsIgnoreCase("exit") || line.equalsIgnoreCase("quit")) break;
            if (line.equalsIgnoreCase("help")) {
                System.out.println("Commands: list, add, done <id>, del <id>, exit");
            } else if (line.equalsIgnoreCase("list")) {
                List<Event> list = manager.all();
                for (Event e : list) {
                    System.out.println(e.getId() + " | " + e.toDisplayString());
                }
            } else if (line.startsWith("done ")) {
                String id = line.substring(5).trim();
                manager.findById(id).ifPresent(e -> { e.setDone(true); manager.update(e); });
            } else if (line.startsWith("del ")) {
                String id = line.substring(4).trim();
                manager.removeById(id);
            } else if (line.equalsIgnoreCase("add")) {
                System.out.print("Title: "); String title = sc.nextLine().trim();
                System.out.print("Description: "); String desc = sc.nextLine().trim();
                System.out.print("Date (yyyy-MM-dd): "); LocalDate d = LocalDate.parse(sc.nextLine().trim());
                System.out.print("Time (HH:mm): "); LocalTime t = LocalTime.parse(sc.nextLine().trim());
                System.out.print("Repeat (NONE/DAILY/WEEKLY): "); Event.Repeat rep = Event.Repeat.valueOf(sc.nextLine().trim().toUpperCase());
                Event e = new Event(title, desc, LocalDateTime.of(d, t), rep);
                manager.add(e);
                System.out.println("Added: " + e.getId());
            } else {
                System.out.println("Unknown command.");
            }
            System.out.print("> ");
        }

        scheduler.stop();
        System.out.println("Goodbye.");
    }
}
package com.bablu.reminder.ui;

import com.bablu.reminder.core.Event;
import com.bablu.reminder.core.EventManager;
import com.bablu.reminder.core.ReminderScheduler;
import com.bablu.reminder.storage.Storage;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class JavaFXUI extends Application {

    private final Storage storage = new Storage();
    private final EventManager manager = new EventManager(storage);
    private final ObservableList<Event> model = FXCollections.observableArrayList(manager.all());
    private ReminderScheduler scheduler;

    private final DateTimeFormatter FMT_DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter FMT_TIME = DateTimeFormatter.ofPattern("HH:mm");
    private final DateTimeFormatter FMT_DATE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private StackPane rootStack;

    public static void launchApp(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        rootStack = new StackPane();
        rootStack.setPadding(new Insets(24));
        rootStack.setStyle("-fx-background-color: linear-gradient(to bottom right, #0f172a, #111827);");

        BorderPane layout = new BorderPane();
        layout.setMaxWidth(1000);
        layout.setPrefWidth(1000);
        layout.setStyle("-fx-background-color: rgba(255,255,255,0.04); -fx-background-radius: 24;");
        layout.setPadding(new Insets(16));

        HBox header = new HBox(12);
        Label title = new Label("Event Reminder");
        title.setFont(Font.font("Arial", 28));
        title.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        TextField search = new TextField();
        search.setPromptText("Search by title...");
        Button addBtn = new Button("Add");
        stylePrimary(addBtn);
        header.getChildren().addAll(title, spacer, search, addBtn);
        header.setAlignment(Pos.CENTER_LEFT);
        layout.setTop(header);

        TableView<Event> table = new TableView<>(model);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.getStyleClass().add("modern-table");
        table.setPlaceholder(new Label("No events yet — add one!"));
        TableColumn<Event, String> colTitle = new TableColumn<>("Title");
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));

        TableColumn<Event, String> colDesc = new TableColumn<>("Description");
        colDesc.setCellValueFactory(new PropertyValueFactory<>("description"));

        TableColumn<Event, String> colDate = new TableColumn<>("Date");
        colDate.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getDateTime().format(FMT_DATE)));

        TableColumn<Event, String> colTime = new TableColumn<>("Time");
        colTime.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getDateTime().format(FMT_TIME)));

        TableColumn<Event, String> colRepeat = new TableColumn<>("Repeat");
        colRepeat.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getRepeat().name()));

        TableColumn<Event, String> colStatus = new TableColumn<>("Status");
        colStatus.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().isDone() ? "Done" : "Pending"));

        table.getColumns().addAll(colTitle, colDesc, colDate, colTime, colRepeat, colStatus);

        HBox actions = new HBox(8);
        Button editBtn = new Button("Edit");
        Button doneBtn = new Button("Mark Done");
        Button delBtn = new Button("Delete");
        styleSecondary(editBtn);
        styleSecondary(doneBtn);
        styleDanger(delBtn);
        actions.getChildren().addAll(editBtn, doneBtn, delBtn);
        actions.setAlignment(Pos.CENTER_RIGHT);
        actions.setPadding(new Insets(12, 0, 0, 0));

        VBox center = new VBox(12, table, actions);
        center.setPadding(new Insets(8, 4, 0, 4));
        layout.setCenter(center);

        Label footer = new Label("Your reminders are saved locally in your profile. Daily/Weekly repeats supported.");
        footer.setStyle("-fx-text-fill: rgba(255,255,255,0.6); -fx-font-size: 12;");
        layout.setBottom(new HBox(footer));

        rootStack.getChildren().add(layout);
        StackPane.setAlignment(layout, Pos.CENTER);

        Scene scene = new Scene(rootStack, 1150, 700);
        // Try to load packaged CSS; if not found, continue without failing.
        try {
            var cssUrl = JavaFXUI.class.getResource("theme.css");
            if (cssUrl != null) {
                scene.getStylesheets().add(cssUrl.toExternalForm());
            }
        } catch (Exception ignore) {}

        // Optional icon (packaged at /icons/reminder.png)
        try {
            var iconUrl = JavaFXUI.class.getResource("/icons/reminder.png");
            if (iconUrl != null) {
                stage.getIcons().add(new Image(iconUrl.toExternalForm()));
            }
        } catch (Exception ignore) {}

        stage.setTitle("Event Reminder (Modern JavaFX)");
        stage.setScene(scene);
        stage.show();

        // interactions
        addBtn.setOnAction(e -> openEditor(null));
        editBtn.setOnAction(e -> {
            Event selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) openEditor(selected);
        });
        delBtn.setOnAction(e -> {
            Event selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                boolean ok = confirm("Delete Event", "Are you sure you want to delete \"" + selected.getTitle() + "\"?");
                if (ok) {
                    manager.removeById(selected.getId());
                    model.setAll(manager.all());
                    toast("Deleted \"" + selected.getTitle() + "\"");
                }
            }
        });
        doneBtn.setOnAction(e -> {
            Event selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                selected.setDone(true);
                manager.update(selected);
                model.setAll(manager.all());
                toast("Marked as done");
            }
        });

        // live search
        search.textProperty().addListener((obs, oldV, newV) -> {
            String q = newV == null ? "" : newV.trim().toLowerCase();
            if (q.isEmpty()) {
                model.setAll(manager.all());
            } else {
                model.setAll(manager.all().stream()
                        .filter(ev -> ev.getTitle().toLowerCase().contains(q))
                        .toList());
            }
        });

        // start scheduler
        scheduler = new ReminderScheduler(manager, e -> {
            toast("Reminder: " + e.getTitle() + " @ " + e.getDateTime().format(FMT_DATE_TIME));
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("Reminder: " + e.getTitle());
            alert.setContentText(e.getDescription() == null ? "" : e.getDescription());
            alert.show();
            model.setAll(manager.all());
        });
        scheduler.start();
    }

    @Override
    public void stop() {
        if (scheduler != null) scheduler.stop();
        Platform.exit();
    }

    private void openEditor(Event toEdit) {
        Dialog<Event> dialog = new Dialog<>();
        dialog.setTitle(toEdit == null ? "Add Event" : "Edit Event");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL, ButtonType.OK);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);
        grid.setPadding(new Insets(10));

        TextField title = new TextField();
        title.setPromptText("Event title");
        TextArea desc = new TextArea();
        desc.setPromptText("Description (optional)");
        desc.setPrefRowCount(3);

        DatePicker date = new DatePicker(LocalDate.now());
        Spinner<Integer> hour = new Spinner<>(0, 23, 9);
        Spinner<Integer> minute = new Spinner<>(0, 59, 0);
        hour.setEditable(true);
        minute.setEditable(true);

        ComboBox<Event.Repeat> repeat = new ComboBox<>();
        repeat.getItems().setAll(Event.Repeat.values());
        repeat.getSelectionModel().select(Event.Repeat.NONE);

        if (toEdit != null) {
            title.setText(toEdit.getTitle());
            desc.setText(toEdit.getDescription());
            date.setValue(toEdit.getDateTime().toLocalDate());
            hour.getValueFactory().setValue(toEdit.getDateTime().getHour());
            minute.getValueFactory().setValue(toEdit.getDateTime().getMinute());
            repeat.getSelectionModel().select(toEdit.getRepeat());
        }

        grid.add(new Label("Title"), 0, 0); grid.add(title, 1, 0);
        grid.add(new Label("Description"), 0, 1); grid.add(desc, 1, 1);
        grid.add(new Label("Date"), 0, 2); grid.add(date, 1, 2);
        grid.add(new Label("Time (HH:mm)"), 0, 3);
        HBox timeBox = new HBox(6, hour, new Label(":"), minute);
        grid.add(timeBox, 1, 3);
        grid.add(new Label("Repeat"), 0, 4); grid.add(repeat, 1, 4);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(bt -> {
            if (bt == ButtonType.OK) {
                LocalDate d = date.getValue();
                LocalTime t = LocalTime.of(hour.getValue(), minute.getValue());
                LocalDateTime dt = LocalDateTime.of(d, t);
                if (toEdit == null) {
                    return new Event(title.getText().trim(), desc.getText().trim(), dt, repeat.getValue());
                } else {
                    return new Event(toEdit.getId(), title.getText().trim(), desc.getText().trim(), dt, repeat.getValue(), toEdit.isDone());
                }
            }
            return null;
        });

        Optional<Event> result = dialog.showAndWait();
        result.ifPresent(ev -> {
            if (toEdit == null) {
                manager.add(ev);
                toast("Added \"" + ev.getTitle() + "\" for " + ev.getDateTime().format(FMT_DATE_TIME));
            } else {
                manager.update(ev);
                toast("Updated \"" + ev.getTitle() + "\"");
            }
            model.setAll(manager.all());
        });
    }

    private void toast(String message) {
        Label lbl = new Label(message);
        lbl.setStyle("-fx-background-color: rgba(30, 64, 175, 0.95); -fx-text-fill: white; -fx-padding: 10 16; -fx-background-radius: 12; -fx-font-size: 13;");
        StackPane wrapper = new StackPane(lbl);
        wrapper.setMouseTransparent(true);
        StackPane.setAlignment(wrapper, Pos.TOP_CENTER);
        rootStack.getChildren().add(wrapper);

        FadeTransition ftIn = new FadeTransition(Duration.millis(250), wrapper);
        ftIn.setFromValue(0); ftIn.setToValue(1);
        ftIn.play();

        new Thread(() -> {
            try { Thread.sleep(2200); } catch (InterruptedException ignored) {}
            Platform.runLater(() -> {
                FadeTransition ftOut = new FadeTransition(Duration.millis(300), wrapper);
                ftOut.setFromValue(1); ftOut.setToValue(0);
                ftOut.setOnFinished(ev -> rootStack.getChildren().remove(wrapper));
                ftOut.play();
            });
        }).start();
    }

    // Confirm dialog helper
    public boolean confirm(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        var result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    // Styling helpers
    private void stylePrimary(Button b) {
        b.setStyle("-fx-background-color: #2563eb; -fx-text-fill: white; -fx-background-radius: 10; -fx-font-weight: bold;");
    }
    private void styleSecondary(Button b) {
        b.setStyle("-fx-background-color: rgba(255,255,255,0.08); -fx-text-fill: white; -fx-background-radius: 10;");
    }
    private void styleDanger(Button b) {
        b.setStyle("-fx-background-color: #ef4444; -fx-text-fill: white; -fx-background-radius: 10;");
    }
}
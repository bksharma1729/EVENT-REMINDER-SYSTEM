package com.bablu.reminder.storage;

import com.bablu.reminder.core.Event;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Storage {

    private final Path file;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public Storage() {
        String userHome = System.getProperty("user.home");
        Path dir = Paths.get(userHome, ".event-reminder");
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            // ignore
        }
        this.file = dir.resolve("events.csv");
    }

    public List<Event> load() {
        List<Event> out = new ArrayList<>();
        if (!Files.exists(file)) return out;
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                String[] p = line.split("\t", -1);
                if (p.length < 6) continue;
                String id = p[0];
                String title = unescape(p[1]);
                String desc = unescape(p[2]);
                LocalDateTime dt = LocalDateTime.parse(p[3], FMT);
                Event.Repeat rep = Event.Repeat.valueOf(p[4]);
                boolean done = Boolean.parseBoolean(p[5]);
                out.add(new Event(id, title, desc, dt, rep, done));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return out;
    }

    public void save(List<Event> events) {
        try (BufferedWriter bw = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            bw.write("# id\ttitle\tdescription\tdateTime\trepeat\tdone\n");
            for (Event e : events) {
                String line = String.join("\t",
                        e.getId(),
                        escape(e.getTitle()),
                        escape(e.getDescription() == null ? "" : e.getDescription()),
                        e.getDateTime().format(FMT),
                        e.getRepeat().name(),
                        Boolean.toString(e.isDone())
                );
                bw.write(line);
                bw.write("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n");
    }

    private String unescape(String s) {
        return s.replace("\\n", "\n").replace("\\t", "\t").replace("\\\\", "\\");
    }
}
@echo off
REM ===== Event Reminder System Launcher (Windows) =====
REM Java 17+ required.
REM Uses your fixed JavaFX path. Adjust if you installed JavaFX elsewhere.

set "JAVA=java"
set "MP=C:\openjfx-24.0.2_windows-x64_bin-sdk\javafx-sdk-24.0.2\lib"
set "SRC=src"
set "OUT=out"

echo == Preparing sources list ==
del /q sources.txt 2>nul
for /r "%SRC%" %%f in (*.java) do @echo %%f>>sources.txt

if not exist "%OUT%" mkdir "%OUT%"

echo == Compiling ==
"%JAVA%C" 2>nul 1>nul
REM Compile java files
javac --module-path "%MP%" --add-modules javafx.controls,javafx.graphics -d "%OUT%" @sources.txt
if errorlevel 1 (
  echo Compilation failed. See errors above.
  pause
  goto :eof
)

echo == Copying resources ==
REM Copy UI css and fxml to classpath
if not exist "%OUT%\com\bablu\reminder\ui" mkdir "%OUT%\com\bablu\reminder\ui"
copy /y "%SRC%\com\bablu\reminder\ui\theme.css" "%OUT%\com\bablu\reminder\ui\" >nul
copy /y "%SRC%\com\bablu\reminder\ui\MainView.fxml" "%OUT%\com\bablu\reminder\ui\" >nul

REM Copy icons folder to classpath root
if not exist "%OUT%\icons" mkdir "%OUT%\icons"
copy /y "%SRC%\icons\reminder.png" "%OUT%\icons\" >nul

echo == Running ==
"%JAVA%" --enable-native-access=javafx.graphics --module-path "%MP%" --add-modules javafx.controls,javafx.graphics -cp "%OUT%" com.bablu.reminder.Main
pause